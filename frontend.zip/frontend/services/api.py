﻿# Ce fichier est pret pour le lien backend mais fonctionne en autonomie
def fake_login(email, password):
    if email == "admin@ai.com" and password == "admin":
        return {"success": True}
    return {"success": False, "message": "Identifiants invalides"}

def analyze_content(text):
    # Simulation d'un appel IA
    import time
    time.sleep(1) # Simule le temps de reflexion de l'IA
    return {"is_phishing": True, "confidence": 98.4}
