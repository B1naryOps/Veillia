﻿import customtkinter as ctk
from theme.theme import *

class Sidebar(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, width=280, corner_radius=0, fg_color="#000000")
        self.parent = parent
        self.grid_propagate(False)
        self.build_ui()

    def build_ui(self):
        # Logo Glow iOS 26
        ctk.CTkLabel(self, text="AI GUARDIAN", font=(FONT, 22, "bold"), text_color=ACCENT_PINK).pack(pady=(50, 40))
        
        menu_items = [
            ("Dashboard", "D", self.parent.show_stats_view),
            ("Analyses IA", "A", self.parent.show_analysis_view),
            ("Menaces", "M", None),
            ("Logs d'Audit", "L", None),
            ("Parametres", "P", None)
        ]

        for name, icon, cmd in menu_items:
            btn = ctk.CTkButton(
                self, text=f"  {name}", height=50, anchor="w",
                fg_color="transparent", text_color=TEXT_MUTED,
                hover_color=CARD_BG, corner_radius=15, 
                font=(FONT, 15, "bold"), command=cmd if cmd else None
            )
            btn.pack(fill="x", padx=20, pady=5)

        # Status Apple Style
        status_card = ctk.CTkFrame(self, fg_color="#121217", height=80, corner_radius=20, border_width=1, border_color=CARD_BORDER)
        status_card.pack(side="bottom", pady=30, padx=20, fill="x")
        status_card.pack_propagate(False)
        
        ctk.CTkLabel(status_card, text="SYSTEME ACTIF", font=(FONT, 10, "bold"), text_color=SUCCESS).pack(pady=(15, 0))
        ctk.CTkLabel(status_card, text="iOS 26 Core", font=(FONT, 12), text_color=TEXT_MUTED).pack()
