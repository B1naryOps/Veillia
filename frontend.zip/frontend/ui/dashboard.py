﻿import customtkinter as ctk
from ui.sidebar import Sidebar
from theme.theme import *

class Dashboard(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=BG_MAIN)
        self.app = app
        self.columnconfigure(1, weight=1); self.rowconfigure(0, weight=1)
        self.build_ui()

    def build_ui(self):
        Sidebar(self).grid(row=0, column=0, sticky="ns")
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.grid(row=0, column=1, sticky="nsew", padx=45, pady=35)
        self.show_stats_view()

    def clear(self):
        for w in self.container.winfo_children(): w.destroy()

    def show_stats_view(self):
        self.clear()
        ctk.CTkLabel(self.container, text="Bonjour, Admin", font=(FONT, 42, "bold"), text_color=TEXT_MAIN).pack(anchor="w", pady=(0, 40))

        # 1. Cartes Widgets iOS 26
        cards_frame = ctk.CTkFrame(self.container, fg_color="transparent")
        cards_frame.pack(fill="x")

        stats = [("Menaces", "128", SUCCESS, 0.8), ("Alertes", "7", WARNING, 0.4), ("Risque", "LOW", ACCENT_CYAN, 0.2)]
        for t, v, c, p in stats:
            card = ctk.CTkFrame(cards_frame, fg_color=CARD_BG, corner_radius=CORNER_RADIUS, height=200, width=280, border_width=1, border_color=CARD_BORDER)
            card.pack(side="left", padx=12, expand=True, fill="both")
            card.pack_propagate(False)
            
            ctk.CTkLabel(card, text=t, font=(FONT, 14, "bold"), text_color=TEXT_MUTED).pack(pady=(30, 5))
            ctk.CTkLabel(card, text=v, font=(FONT, 48, "bold"), text_color=c).pack()
            
            pb = ctk.CTkProgressBar(card, width=160, height=8, progress_color=c, fg_color="#24262B")
            pb.set(p); pb.pack(pady=25)

        # 2. Zone Logs (Restauree et Amelioree)
        ctk.CTkLabel(self.container, text="Activite en temps reel", font=(FONT, 22, "bold"), text_color=TEXT_MAIN).pack(anchor="w", pady=(50, 20))
        log_box = ctk.CTkFrame(self.container, fg_color=CARD_BG, corner_radius=CORNER_RADIUS, border_width=1, border_color=CARD_BORDER)
        log_box.pack(fill="both", expand=True)
        
        for i in range(4):
            line = ctk.CTkFrame(log_box, fg_color="#1C1E21" if i%2==0 else "transparent", height=55, corner_radius=15)
            line.pack(fill="x", padx=20, pady=8)
            ctk.CTkLabel(line, text=f" [SECURE] Scanning node {i+1}... Access Granted", font=(FONT, 13), text_color=ACCENT_CYAN).pack(side="left", padx=25)

    def show_analysis_view(self):
        self.clear()
        ctk.CTkLabel(self.container, text="Intelligence Artificielle", font=(FONT, 42, "bold"), text_color=ACCENT_PINK).pack(anchor="w", pady=(0, 40))
        
        card = ctk.CTkFrame(self.container, fg_color=CARD_BG, corner_radius=CORNER_RADIUS, border_width=2, border_color=ACCENT_PINK)
        card.pack(fill="both", expand=True)

        ctk.CTkLabel(card, text="Scanner un contenu suspect", font=(FONT, 20, "bold")).pack(pady=35)
        txt = ctk.CTkTextbox(card, height=250, fg_color="#0A0B0D", border_width=1, border_color=CARD_BORDER, corner_radius=25, font=(FONT, 14))
        txt.pack(fill="x", padx=50, pady=10)

        # Barre de Scan Siri-Liquide
        self.scan_bar = ctk.CTkProgressBar(card, height=12, progress_color=ACCENT_VIOLET, fg_color="#24262B")
        self.scan_bar.set(0); self.scan_bar.pack(fill="x", padx=120, pady=40)

        ctk.CTkButton(card, text="Lancer l'Analyse Photonique", height=60, width=350, corner_radius=25, 
                      fg_color=ACCENT_VIOLET, hover_color=ACCENT_PINK, font=(FONT, 18, "bold"), command=self.run_scan).pack(pady=10)

    def run_scan(self):
        import time
        for i in range(101):
            self.scan_bar.set(i/100)
            if i % 15 == 0: self.scan_bar.configure(progress_color=ACCENT_CYAN if i % 30 == 0 else ACCENT_PINK)
            self.update(); time.sleep(0.015)
