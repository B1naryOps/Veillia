﻿import customtkinter as ctk
from theme.theme import *
from services.api import fake_login
from ui.dashboard import Dashboard

class LoginScreen(ctk.CTkFrame):
    def __init__(self, parent, app):
        # On ajoute une bordure de couleur vive pour l'effet "Liquid"
        super().__init__(parent, fg_color=CARD_BG, corner_radius=CORNER_RADIUS, 
                         border_width=2, border_color=ACCENT_VIOLET)
        self.app = app
        self.configure(width=450, height=550)
        self.grid_propagate(False)
        self.build_ui()

    def build_ui(self):
        # Titre avec effet de couleur Cyan (Apple Intelligence style)
        ctk.CTkLabel(self, text="AI Guardian", font=(FONT, 42, "bold"), text_color=ACCENT_CYAN).pack(pady=(60, 5))
        ctk.CTkLabel(self, text="FUTURE OF SECURITY", font=(FONT, 10, "bold"), text_color=ACCENT_PINK).pack(pady=(0, 50))

        self.email = self.create_input(self, "Identifiant")
        self.password = self.create_input(self, "Mot de passe", show="*")
        
        # Le label d'erreur qui utilisait DANGER
        self.error = ctk.CTkLabel(self, text="", text_color=DANGER, font=(FONT, 12))
        self.error.pack(pady=5)

        # Bouton avec couleur Violette vibrante
        btn = ctk.CTkButton(self, text="Ouvrir la Session", height=58, width=320, 
                            corner_radius=22, fg_color=ACCENT_VIOLET, hover_color=PRIMARY,
                            font=(FONT, 16, "bold"), command=self.login)
        btn.pack(pady=(40, 0))

    def create_input(self, parent, placeholder, **kwargs):
        e = ctk.CTkEntry(parent, placeholder_text=placeholder, width=330, height=54, 
                         border_width=1, border_color=CARD_BORDER, corner_radius=18, 
                         fg_color="#101014", font=(FONT, 14), **kwargs)
        e.pack(pady=12)
        return e

    def login(self):
        res = fake_login(self.email.get(), self.password.get())
        if res["success"]:
            for w in self.app.container.winfo_children(): w.destroy()
            dash = Dashboard(self.app.container, self.app)
            dash.pack(fill="both", expand=True)
        else:
            self.error.configure(text=res["message"])
