﻿import customtkinter as ctk
from ui.login import LoginScreen
from theme.theme import BG_MAIN

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("AI Guardian - iOS 26 Edition")
        self.geometry("1150x750")
        
        # On utilise le bleu spatial defini dans le theme
        self.configure(fg_color=BG_MAIN)
        
        # Conteneur principal
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.pack(fill="both", expand=True)
        
        self.show_login()

    def show_login(self):
        # On place le login au centre avec une petite animation
        view = LoginScreen(self.container, self)
        view.place(relx=0.5, rely=0.5, anchor="center")

if __name__ == "__main__":
    app = App()
    app.mainloop()
